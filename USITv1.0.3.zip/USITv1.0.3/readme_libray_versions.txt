These programs require the following libraries:

OpenCV version 2.4 (http://opencv.org)
Boost version 1.53 (http://www.boost.org)
    specifically: 
        - filesystem
        - system
        - regex
